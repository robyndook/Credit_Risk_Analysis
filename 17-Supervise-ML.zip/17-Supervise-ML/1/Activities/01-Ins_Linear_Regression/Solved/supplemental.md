[Interpreting Residual Plots](http://docs.statwing.com/interpreting-residual-plots-to-improve-your-regression/)

[Linear Regression](http://cs229.stanford.edu/notes/cs229-notes1.pdf)
